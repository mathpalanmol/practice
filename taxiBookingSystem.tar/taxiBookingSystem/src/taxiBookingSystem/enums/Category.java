package taxiBookingSystem.enums;

public enum Category {MINI, SEDAN, SUV, SHARE, OUTSTATION}
