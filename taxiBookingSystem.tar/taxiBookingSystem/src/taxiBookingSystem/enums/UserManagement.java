package taxiBookingSystem.enums;

import java.util.ArrayList;
import java.util.List;

public class UserManagement {
	List<User> activeUsers = new ArrayList<User>();

	long getActiveUserCount() {
		return activeUsers.size();
	}

	void addUser(User user) {
		activeUsers.add(user);
	}

	void removeUser(User user) {
		activeUsers.remove(user);
	}

	static class User {
		long id;

		public User(long id) {
			super();
			this.id = id;
		}

	}
}
